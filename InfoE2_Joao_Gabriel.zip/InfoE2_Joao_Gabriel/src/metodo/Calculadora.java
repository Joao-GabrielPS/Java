/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package metodo;

/**
 *
 * @author 12409864678
 */
public class Calculadora {
    public int multiplicar(int numero1, int numero2) {
        return numero1*numero2;
    }
    
        public int dividir(int numero1, int numero2) {
        return numero1/numero2;
    }
}
