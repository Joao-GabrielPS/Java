/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package metodo;

/**
 *
 * @author 12409864678
 */
public class ExemploMetodo1 {
    //metodo para com void para relatorio
    public static void mostrarMensagem(){
        System.out.println("Olá, seja bem vindo");
    }
    public static void main(String[] args) {
        
        mostrarMensagem();
        mostrarMensagem();
    }
}
