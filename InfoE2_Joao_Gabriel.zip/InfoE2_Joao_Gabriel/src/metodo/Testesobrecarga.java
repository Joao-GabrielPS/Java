/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package metodo;

/**
 *
 * @author 12409864678
 */
public class Testesobrecarga {
    public static void main(String[] args) {
        Sobrecarga obj = new Sobrecarga();
        obj.exibir("Olá");
        obj.exibir(100);
        
    }
    
}
